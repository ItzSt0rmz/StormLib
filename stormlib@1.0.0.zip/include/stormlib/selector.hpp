extern bool isRed, isLeft, isSkills;
extern int currentScreen;
extern int currentAuton;
extern void selector_initialize();